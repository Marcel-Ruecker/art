import{r as s,j as n}from"./chunk-BNVGILX8.js";const p=s.forwardRef(({type:t="submit",children:r,...e},o)=>n.jsx("button",{type:t,...e,ref:o,children:r}));p.displayName="Button";export{p as n};
