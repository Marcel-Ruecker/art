import{j as n,R as m,a as s,i as l,P as h,b as p,c as v}from"../chunks/chunk-BNVGILX8.js";import{l as t,m as i,y as g}from"../chunks/chunk-BVYZiTBp.js";import{P as c}from"../chunks/chunk-CldwJJ1n.js";/* empty css                      */const r=void 0,x=[{id:"jAWQK3_7D18H_5v0pK0z4"},{id:"mONS0so-VrF1uS9rPlVcF",maxWidth:991},{id:"zGIdqUzdPde7sHmF0aRQP",maxWidth:767},{id:"wP-rcJFENR2yn86VzREAn",maxWidth:479}],y="logo_r1qaJQiri6sK3rPyq-Sar.svg",S=["OpenSans-ExtraBoldItalic_XWDxhVGX3UIyP1_SBhKRH.ttf","OpenSans-ExtraBold_Vm8wCOMRHs-JNp5ZxL7Ju.ttf","OpenSans-SemiboldItalic_3uMcVa9LMLBFQ2e5ddGU6.ttf","OpenSans-BoldItalic_PIxeEUIoe52Ake4GOYkZp.ttf","OpenSans-LightItalic__gJQObS3RVADe6dXpz76S.ttf","OpenSans-Bold_K4pUwy_ixGuyBdMGnXUuG.ttf","OpenSans-Italic_Ln-FcaFDUW0pZf-yIoLxR.ttf","OpenSans-Semibold_9U4pQOYgO6t9S5-S6v-ni.ttf","OpenSans-Light_euls2YDcDFPbhqKAdUWcW.ttf","OpenSans-Regular_xgbNTDF25zTfZIyrbNY0i.ttf"],w=[],f=e=>n.jsx("body",{className:"w-element w-element-1",children:n.jsxs("div",{className:"w-element w-page-wrapper-5",children:[n.jsx(t,{children:n.jsx(i,{children:n.jsx("div",{className:"w-element w-header-13",children:n.jsx("h1",{className:"w-element w-element-2",children:"Marcel Rücker"})})})}),n.jsx(t,{children:n.jsx(i,{children:n.jsxs("nav",{className:"w-element w-navigator",children:[n.jsx("div",{className:"w-element w-avatar-wrapper",children:n.jsx(g,{src:"/assets/Lara_Project_-_Mechanic-1_SlGU9vZt0x40EVQ7LI9AJ.png",width:600,height:600,alt:"",className:"w-image w-image-4"})}),n.jsx("div",{className:"w-element",children:n.jsxs("div",{className:"w-element w-nav-buttons",children:[n.jsx("a",{href:"/",className:"w-element w-portfolio-link",children:"Portfolio"}),n.jsx("a",{href:"/animation-reel",className:"w-element w-nav-link-animation-reel",children:"Animation Reel"}),n.jsx("a",{href:"/storyboards",className:"w-element w-nav-link-storyboards",children:"Storyboards"}),n.jsx("a",{href:"/character-design",className:"w-element w-nav-link",children:"Character Design"}),n.jsx("a",{href:"/sketchbook",className:"w-element w-nav-link-1",children:"Sketchbook"}),n.jsx("a",{href:"/illustration",className:"w-element w-nav-link-2",children:"Illustration"}),n.jsx("a",{href:"/resume",className:"w-element w-nav-link-3",children:"Resume"})]})})]})})}),n.jsx("div",{className:"w-element w-content-box-5",children:n.jsxs("div",{className:"w-element w-storyboards-wrapper",children:[n.jsx("h1",{className:"w-element w-storyboards",children:"Storyboards"}),n.jsx("div",{className:"w-element",children:n.jsx(c,{executeScriptOnCanvas:!0,code:`<style>
.mySlides, .mySlides1 {display: none}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}
</style>



<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1Yssi_nfOHiuCgOEj_iqF974gWjIIGCa4=s900?authuser=0" style="width:100%">
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1fl5nDP-rYADCe_PwJtIck_4bmctMtXbw=s900?authuser=0" style="width:100%">
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1VbLrBGJN-0AJSLPSmppFMYFh293MZ8Fl=s900?authuser=0" style="width:100%">
</div>

<div class="mySlides fade">
  <div class="numbertext">4 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1yBODYOoz1u_DO-hnBfQfLAlYxQS2EsCf=s900?authuser=0" style="width:100%">
</div>
  
<div class="mySlides fade">
  <div class="numbertext">5 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/16-N70DR5I6eOEIlRp5Q1puBUK1kQA4qu=s900?authuser=0" style="width:100%">
</div>

<div class="mySlides fade">
  <div class="numbertext">6 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1NSrVQ3vBUup7oXB7M9nCDClH-QnUXKAt=s900?authuser=0" style="width:100%">
</div>
  
<div class="mySlides fade">
  <div class="numbertext">7 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1rFPJMnzLW5NgJC-juXmhZA5znrPWyWgp=s900?authuser=0" style="width:100%">
</div>

<div class="mySlides fade">
  <div class="numbertext">8 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1UDI2EZhZWz9q49GMaNMQPhhiTAX-pK80=s900?authuser=0" style="width:100%">
</div>

<div class="mySlides fade">
  <div class="numbertext">9 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1t9q8tGg9hEBvW5c3t-6v8hOlbtyILeec=s900?authuser=0" style="width:100%">
</div>

<div class="mySlides fade">
  <div class="numbertext">10 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1uDzkmhgy9EirMhTu2xvs8AXCjAsq3myQ=s900?authuser=0" style="width:100%">
</div>

<div class="mySlides fade">
  <div class="numbertext">11 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/17_MBBOvjL2QzKCvYx5CbrabO58p-m1oA=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">12 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1QBjC0kQynOCX35NELHWkOaKnllN4sGtg=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">13 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1xp23qMbnvut9193_45bRMAie2BvYmc4u=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">14 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1EW1oTDgPsiDhit20XA5EqkclHbsjcljY=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">15 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1_ZbGxHVFfFR35WpvyREW5hSF_HX-mNy_=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">16 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1RzXFMhOmBnNcY586bpwV54Qk2oC0ZhJh=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">17 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1IqFWkAunzNiMKr0Lftda6svWkJzlx44i=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">18 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1jSuu_vCYMjMqN-8npAGuMGmvugdNz4FX=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">19 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1lfbJypjVb5O75_3ogodX93vzDV6wBVD2=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">20 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1FiK6yKHpNKWSezuk02U3EZZNweNwm41h=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">21 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1wR4DlnosiQzSjkyYmHd5PNStP2nWJwBo=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">22 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/13NMLhz_t2dFdL_2DSl-z8n4w5TVQU7D7=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">23 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/10hqMf8KrstqkueXZcChBt8HQC8De37jv=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">24 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1DSX8s46MYDqoiQEYJVTG9v0JS2HgE78i=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">25 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1hVAakTGJxcLGuu6uVZQecExLeldeuas8=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">26 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1A7Z_y-G7gNolmiiSoZlpGpJ_5jE7oggi=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">27 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1eIJxOCLVVuwvxtdELTtPCE5VqDCXraHz=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">28 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/16nIqqgVE0k8I_Ww7-5zAhr9jq7LbR_FS=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">29 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1pH4PSrNUbdeO-CiU6_hXdao4MSr0HXnS=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">30 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1bUiwnt8DLU1IlS0556DNLJfI0VHZXCX8=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">31 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1LdTb2AWJPDNDKbSso3KZ0-jLwBLCW3zS=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">32 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1_5VNyglpJmN23kXGobj-3thxlLz_uAZ4=s900?authuser=0" style="width:100%">
</div>


<div class="mySlides fade">
  <div class="numbertext">33 / 33</div>
  <img src="https://lh3.googleusercontent.com/d/1L3WUytf89ntI4GOTmsJHfcPIhSqQLZyl=s900?authuser=0" style="width:100%">
</div>

<a class="prev" onclick="plusSlides(-1)">❮</a>
<a class="next" onclick="plusSlides(1)">❯</a>

</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
    <span class="dot" onclick="currentSlide(4)"></span> 
    <span class="dot" onclick="currentSlide(5)"></span> 
      <span class="dot" onclick="currentSlide(6)"></span> 
        <span class="dot" onclick="currentSlide(7)"></span> 
          <span class="dot" onclick="currentSlide(8)"></span> 
            <span class="dot" onclick="currentSlide(9)"></span>
  <span class="dot" onclick="currentSlide(10)"></span> 
  <span class="dot" onclick="currentSlide(11)"></span> 
  <span class="dot" onclick="currentSlide(12)"></span> 
  <span class="dot" onclick="currentSlide(13)"></span> 
  <span class="dot" onclick="currentSlide(14)"></span> 
  <span class="dot" onclick="currentSlide(15)"></span> 
  <span class="dot" onclick="currentSlide(16)"></span> 
  <span class="dot" onclick="currentSlide(17)"></span> 
  <span class="dot" onclick="currentSlide(18)"></span> 
  <span class="dot" onclick="currentSlide(19)"></span> 
  <span class="dot" onclick="currentSlide(20)"></span> 
  <span class="dot" onclick="currentSlide(21)"></span> 
  <span class="dot" onclick="currentSlide(22)"></span> 
  <span class="dot" onclick="currentSlide(23)"></span> 
  <span class="dot" onclick="currentSlide(24)"></span> 
  <span class="dot" onclick="currentSlide(25)"></span> 
  <span class="dot" onclick="currentSlide(26)"></span> 
  <span class="dot" onclick="currentSlide(27)"></span> 
  <span class="dot" onclick="currentSlide(28)"></span> 
  <span class="dot" onclick="currentSlide(29)"></span> 
  <span class="dot" onclick="currentSlide(30)"></span> 
  <span class="dot" onclick="currentSlide(31)"></span> 
  <span class="dot" onclick="currentSlide(32)"></span> 
  <span class="dot" onclick="currentSlide(33)"></span> 
</div>

<script>
let slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
<\/script>`,className:"w-html-embed"})}),n.jsx("div",{className:"w-element",children:n.jsx(c,{executeScriptOnCanvas:!0,code:`<style>
.mySlides, .mySlides1 {display: none}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}
</style>



<div class="slideshow-container">

<div class="mySlides1 fade">
  <div class="numbertext">1 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1mjVrvSFtQyyFLvXnlxyxux3frPw_1ZQM=s900?authuser=0" style="width:100%">
</div>

<div class="mySlides1 fade">
  <div class="numbertext">2 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/19M-nRxewLblkAJ8W7Oy0EwWzV9VGdUON=s900?authuser=0" style="width:100%">
</div>

<div class="mySlides1 fade">
  <div class="numbertext">3 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1Xrxm7tatpU19g40LZCTFlsStyj0Ai6f8=s900?authuser=0" style="width:100%">
</div>

<div class="mySlides1 fade">
  <div class="numbertext">4 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/114GSPZxkJDzq4IHET4XkwUWCWQ39kURZ=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">5 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1LlSML99K9ULz53m9dPwLBjV7kiOU0OT9=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">6 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1dIUzkJJaBLlTJcYD5ft4DVSF4W2GHDGE=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">7 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1bQEDHvQQfobRexKBU8-1XhiwDgWaLc_Q=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">8 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1rr4WxmajJGjO25bwOjjTHUz9Bdge2r_8=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">9 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1EGkwVFosxZ3fydzufw-cIIQzVJXKU2yy=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">10 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1Qs1C3SClnyCFcVhjFMsMI32s64vpZhXV=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">11 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1lJC5K2bItsYyjJkOU1XOq-cQ45VuI5r4=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">12 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1AQP5N3JfUzdtdmalRCPUu7elxFmN0sxG=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">13 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1_2wuKgHMoEo17UxL2xkaBmDKAMkWDUTE=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">14 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1vn8tihCMpfGVPjdOK9R9huu_vRo-TfS3=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">15 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/13vgFR1zLiMrFNlFcqWv3KIJkfugduOHB=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">16 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1sqvnsz7FyqDKmMfNVan28tUIkx_cTfBz=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">17 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1I06iy8PqZt0uI2xzqSLGyDtcM69il4GT=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">18 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1bjgGznZ_OA0SIVjGMmW3CxxkVRmMh2A5=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">19 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1ZrnJAEQCZDmGsE1RV2E0cBH8ZIdbNEZG=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">20 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1wk--XgQ3JylgAY7OReUl--gGLyP_pYb-=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">21 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1T-i-b35qC_b3cs7fhk5fHlHsRgveYD0S=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">22 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1dQh5Tj_gcjRUeapeTbyz-yiWODDMz3cD=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">23 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1NbllkTLAzKRHcp9vsdlzPP2mpCHc6vmA=s900?authuser=0" style="width:100%">
</div>
<div class="mySlides1 fade">
  <div class="numbertext">24 / 24</div>
  <img src="https://lh3.googleusercontent.com/d/1L9r5egmmLXzwrMheHhRTa8PVINDrrOfa=s900?authuser=0" style="width:100%">
</div>
<a class="prev" onclick="plusSlides1(-1)">❮</a>
<a class="next" onclick="plusSlides1(1)">❯</a>

</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide1(1)"></span> 
  <span class="dot" onclick="currentSlide1(2)"></span> 
  <span class="dot" onclick="currentSlide1(3)"></span> 
    <span class="dot" onclick="currentSlide1(4)"></span> 
    <span class="dot" onclick="currentSlide1(5)"></span> 
      <span class="dot" onclick="currentSlide1(6)"></span> 
  <span class="dot" onclick="currentSlide1(7)"></span> 
  <span class="dot" onclick="currentSlide1(8)"></span>  
  <span class="dot" onclick="currentSlide1(9)"></span>  
  <span class="dot" onclick="currentSlide1(10)"></span>  
  <span class="dot" onclick="currentSlide1(11)"></span>  
  <span class="dot" onclick="currentSlide1(12)"></span>  
  <span class="dot" onclick="currentSlide1(13)"></span>  
  <span class="dot" onclick="currentSlide1(14)"></span>  
  <span class="dot" onclick="currentSlide1(15)"></span>  
  <span class="dot" onclick="currentSlide1(16)"></span>  
  <span class="dot" onclick="currentSlide1(17)"></span>  
  <span class="dot" onclick="currentSlide1(18)"></span>  
  <span class="dot" onclick="currentSlide1(19)"></span>  
  <span class="dot" onclick="currentSlide1(20)"></span>  
  <span class="dot" onclick="currentSlide1(21)"></span>  
  <span class="dot" onclick="currentSlide1(22)"></span>  
  <span class="dot" onclick="currentSlide1(23)"></span>  
  <span class="dot" onclick="currentSlide1(24)"></span> 
</div>

<script>
let slideIndex1 = 1;
showSlides1(slideIndex1);

function plusSlides1(n) {
  showSlides1(slideIndex1 += n);
}

function currentSlide1(n) {
  showSlides(slideIndex1 = n);
}

function showSlides1(n) {
  let i;
  let slides1 = document.getElementsByClassName("mySlides1");
  let dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex1 = slides1.length}
  for (i = 0; i < slides1.length; i++) {
    slides1[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides1[slideIndex1-1].style.display = "block";  
  dots[slideIndex1-1].className += " active";
}
<\/script>`,className:"w-html-embed"})})]})}),n.jsx(t,{children:n.jsx(i,{children:n.jsx("footer",{className:"w-element w-footer-1",children:n.jsxs("div",{className:"w-element w-impressum-stuff",children:[n.jsx("div",{className:"w-element",children:n.jsx("a",{href:"/legal-notice",className:"w-element w-element-3",children:"Legal Notice"})}),n.jsx("div",{className:"w-element",children:n.jsx("a",{href:"/privacy-policy",className:"w-element w-element-4",children:"Privacy Policy"})}),n.jsx("div",{className:"w-element w-credits-license",children:n.jsx("a",{href:"/credits-and-license",className:"w-element w-element-5",children:"Credits & License"})})]})})})})]})}),b=({data:e})=>{const{system:o,resources:u,url:d,pageMeta:a}=e;return n.jsxs(m.Provider,{value:{imageLoader:l,assetBaseUrl:s,resources:u,breakpoints:x,onError:console.error},children:[n.jsx(f,{system:o},d),n.jsx(h,{url:d,pageMeta:a,siteName:r,imageLoader:l,assetBaseUrl:s}),n.jsx(p,{children:a.title})]})},k=Object.freeze(Object.defineProperty({__proto__:null,default:b},Symbol.toStringTag,{value:"Module"})),j=({})=>n.jsxs(n.Fragment,{children:[r,n.jsx("link",{rel:"icon",href:l({src:`${s}${y}`})}),S.map(e=>n.jsx("link",{rel:"preload",href:`${s}${e}`,as:"font",crossOrigin:"anonymous"},e)),w.map(e=>n.jsx("link",{rel:"preload",href:`${s}${e}`,as:"image"},e))]}),N=Object.freeze(Object.defineProperty({__proto__:null,Head:j},Symbol.toStringTag,{value:"Module"})),P={isClientRuntimeLoaded:{type:"computed",definedAtData:null,valueSerialized:{type:"js-serialized",value:!0}},onBeforeRenderEnv:{type:"computed",definedAtData:null,valueSerialized:{type:"js-serialized",value:null}},dataEnv:{type:"computed",definedAtData:null,valueSerialized:{type:"js-serialized",value:{server:!0}}},onRenderClient:{type:"standard",definedAtData:{filePathToShowToUser:"/renderer/+onRenderClient.tsx",fileExportPathToShowToUser:[]},valueSerialized:{type:"plus-file",exportValues:v}},Page:{type:"standard",definedAtData:{filePathToShowToUser:"/pages/storyboards/+Page.tsx",fileExportPathToShowToUser:[]},valueSerialized:{type:"plus-file",exportValues:k}},Head:{type:"standard",definedAtData:{filePathToShowToUser:"/pages/storyboards/+Head.tsx",fileExportPathToShowToUser:[]},valueSerialized:{type:"plus-file",exportValues:N}}};export{P as configValuesSerialized};
